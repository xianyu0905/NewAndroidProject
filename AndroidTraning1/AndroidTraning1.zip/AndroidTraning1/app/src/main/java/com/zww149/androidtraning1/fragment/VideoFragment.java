package com.zww149.androidtraning1.fragment;

public class VideoFragment extends BaseFragment {
}
