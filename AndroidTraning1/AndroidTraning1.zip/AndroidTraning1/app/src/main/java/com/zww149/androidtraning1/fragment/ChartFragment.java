package com.zww149.androidtraning1.fragment;

public class ChartFragment extends BaseFragment {
}
