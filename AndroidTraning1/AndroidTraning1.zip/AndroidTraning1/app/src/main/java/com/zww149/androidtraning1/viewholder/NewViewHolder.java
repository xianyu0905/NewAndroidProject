package com.zww149.androidtraning1.viewholder;

import android.view.View;
import com.chad.library.adapter.base.BaseViewHolder;

public class NewViewHolder extends BaseViewHolder {
    public NewViewHolder(View view) {
        super(view);
    }
}
